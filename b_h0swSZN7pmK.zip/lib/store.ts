"use client"

import { create } from 'zustand'
import type { MealPlan, InventoryItem, ShoppingItem, PriceItem, Recipe } from './types'
import { 
  mealPlans as initialMealPlans, 
  inventoryItems as initialInventory,
  shoppingItems as initialShopping,
  priceItems as initialPrices,
  recipes as initialRecipes
} from './mock-data'

interface AppState {
  // 当前选中的标签页
  activeTab: 'home' | 'plan' | 'shopping' | 'inventory' | 'price'
  setActiveTab: (tab: AppState['activeTab']) => void
  
  // 是否显示新建计划页面
  showNewPlan: boolean
  setShowNewPlan: (show: boolean) => void
  
  // 用餐计划
  mealPlans: MealPlan[]
  addMealPlan: (plan: MealPlan) => void
  updateMealPlan: (id: string, plan: Partial<MealPlan>) => void
  deleteMealPlan: (id: string) => void
  
  // 库存
  inventory: InventoryItem[]
  updateInventoryItem: (id: string, quantity: number) => void
  addInventoryItem: (item: InventoryItem) => void
  
  // 采购清单
  shoppingList: ShoppingItem[]
  toggleShoppingItem: (id: string) => void
  updateShoppingQuantity: (id: string, quantity: number) => void
  addShoppingItem: (item: ShoppingItem) => void
  
  // 比价
  priceList: PriceItem[]
  updatePriceItem: (id: string, item: Partial<PriceItem>) => void
  addPriceItem: (item: PriceItem) => void
  
  // 菜谱
  recipes: Recipe[]
  addRecipe: (recipe: Recipe) => void
}

export const useAppStore = create<AppState>((set) => ({
  activeTab: 'home',
  setActiveTab: (tab) => set({ activeTab: tab }),
  
  showNewPlan: false,
  setShowNewPlan: (show) => set({ showNewPlan: show }),
  
  mealPlans: initialMealPlans,
  addMealPlan: (plan) => set((state) => ({ mealPlans: [...state.mealPlans, plan] })),
  updateMealPlan: (id, plan) => set((state) => ({
    mealPlans: state.mealPlans.map((p) => p.id === id ? { ...p, ...plan } : p)
  })),
  deleteMealPlan: (id) => set((state) => ({
    mealPlans: state.mealPlans.filter((p) => p.id !== id)
  })),
  
  inventory: initialInventory,
  updateInventoryItem: (id, quantity) => set((state) => ({
    inventory: state.inventory.map((item) => 
      item.id === id ? { ...item, quantity } : item
    )
  })),
  addInventoryItem: (item) => set((state) => ({ inventory: [...state.inventory, item] })),
  
  shoppingList: initialShopping,
  toggleShoppingItem: (id) => set((state) => ({
    shoppingList: state.shoppingList.map((item) =>
      item.id === id ? { ...item, checked: !item.checked } : item
    )
  })),
  updateShoppingQuantity: (id, quantity) => set((state) => ({
    shoppingList: state.shoppingList.map((item) =>
      item.id === id ? { ...item, quantity } : item
    )
  })),
  addShoppingItem: (item) => set((state) => ({ shoppingList: [...state.shoppingList, item] })),
  
  priceList: initialPrices,
  updatePriceItem: (id, item) => set((state) => ({
    priceList: state.priceList.map((p) => p.id === id ? { ...p, ...item } : p)
  })),
  addPriceItem: (item) => set((state) => ({ priceList: [...state.priceList, item] })),
  
  recipes: initialRecipes,
  addRecipe: (recipe) => set((state) => ({ recipes: [...state.recipes, recipe] })),
}))
