import type { BreakfastOption, Recipe, InventoryItem, MealPlan, ShoppingItem, PriceItem } from './types'

export const breakfastOptions: BreakfastOption[] = [
  { id: '1', name: '燕麦牛奶', emoji: '🥣' },
  { id: '2', name: '包子', emoji: '🥟' },
  { id: '3', name: '煎饼果子', emoji: '🥞' },
  { id: '4', name: '豆浆油条', emoji: '🥢' },
  { id: '5', name: '三明治', emoji: '🥪' },
  { id: '6', name: '粥配小菜', emoji: '🍲' },
  { id: '7', name: '面包咖啡', emoji: '☕' },
  { id: '8', name: '鸡蛋饼', emoji: '🍳' },
]

export const recipes: Recipe[] = [
  {
    id: '1',
    name: '番茄炒蛋',
    category: '家常菜',
    ingredients: [
      { name: '番茄', quantity: 2, unit: '个' },
      { name: '鸡蛋', quantity: 3, unit: '个' },
    ],
  },
  {
    id: '2',
    name: '红烧肉',
    category: '荤菜',
    ingredients: [
      { name: '五花肉', quantity: 500, unit: '克' },
      { name: '冰糖', quantity: 30, unit: '克' },
      { name: '生姜', quantity: 3, unit: '片' },
    ],
  },
  {
    id: '3',
    name: '清炒时蔬',
    category: '素菜',
    ingredients: [
      { name: '青菜', quantity: 300, unit: '克' },
      { name: '蒜末', quantity: 10, unit: '克' },
    ],
  },
  {
    id: '4',
    name: '蒜蓉西兰花',
    category: '素菜',
    ingredients: [
      { name: '西兰花', quantity: 1, unit: '朵' },
      { name: '蒜末', quantity: 15, unit: '克' },
    ],
  },
  {
    id: '5',
    name: '可乐鸡翅',
    category: '荤菜',
    ingredients: [
      { name: '鸡翅', quantity: 8, unit: '个' },
      { name: '可乐', quantity: 330, unit: '毫升' },
      { name: '生姜', quantity: 2, unit: '片' },
    ],
  },
  {
    id: '6',
    name: '酸辣土豆丝',
    category: '家常菜',
    ingredients: [
      { name: '土豆', quantity: 2, unit: '个' },
      { name: '青椒', quantity: 1, unit: '个' },
      { name: '干辣椒', quantity: 5, unit: '个' },
    ],
  },
]

export const inventoryItems: InventoryItem[] = [
  { id: '1', name: '番茄', quantity: 5, unit: '个', addedAt: new Date('2024-04-10') },
  { id: '2', name: '鸡蛋', quantity: 12, unit: '个', addedAt: new Date('2024-04-08') },
  { id: '3', name: '青菜', quantity: 500, unit: '克', addedAt: new Date('2024-04-11') },
  { id: '4', name: '五花肉', quantity: 300, unit: '克', addedAt: new Date('2024-04-09') },
  { id: '5', name: '土豆', quantity: 3, unit: '个', addedAt: new Date('2024-04-07') },
]

// 动态生成今天、明天、后天的日期字符串
function getDateString(daysFromToday: number): string {
  const date = new Date()
  date.setDate(date.getDate() + daysFromToday)
  return date.toISOString().split('T')[0]
}

export const mealPlans: MealPlan[] = [
  {
    id: '1',
    date: getDateString(0), // 今天
    breakfast: { id: '1', name: '燕麦牛奶', emoji: '🥣' },
    recipes: [recipes[0], recipes[2]],
    shoppingListItems: 3,
  },
  {
    id: '2',
    date: getDateString(1), // 明天
    breakfast: { id: '2', name: '包子', emoji: '🥟' },
    recipes: [recipes[1], recipes[3]],
    shoppingListItems: 5,
  },
  {
    id: '3',
    date: getDateString(2), // 后天
    breakfast: { id: '3', name: '煎饼果子', emoji: '🥞' },
    recipes: [recipes[4], recipes[5]],
    shoppingListItems: 4,
  },
]

export const shoppingItems: ShoppingItem[] = [
  { id: '1', name: '番茄', quantity: 4, unit: '个', price: 2.5, store: '永辉超市', checked: false },
  { id: '2', name: '鸡蛋', quantity: 10, unit: '个', price: 1.2, store: '永辉超市', checked: false },
  { id: '3', name: '五花肉', quantity: 500, unit: '克', price: 28.0, store: '菜市场', checked: false },
  { id: '4', name: '青菜', quantity: 300, unit: '克', price: 5.0, store: '菜市场', checked: true },
  { id: '5', name: '西兰花', quantity: 1, unit: '朵', price: 8.0, store: '盒马鲜生', checked: false },
]

export const priceItems: PriceItem[] = [
  { id: '1', ingredient: '番茄', store: '永辉超市', price: 2.5 },
  { id: '2', ingredient: '番茄', store: '菜市场', price: 2.0 },
  { id: '3', ingredient: '鸡蛋', store: '永辉超市', price: 1.2 },
  { id: '4', ingredient: '鸡蛋', store: '盒马鲜生', price: 1.5 },
  { id: '5', ingredient: '五花肉', store: '菜市场', price: 28.0 },
  { id: '6', ingredient: '五花肉', store: '永辉超市', price: 32.0 },
]

// 工具函数
export function formatDate(dateStr: string): string {
  const date = new Date(dateStr)
  const month = date.getMonth() + 1
  const day = date.getDate()
  const weekdays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']
  const weekday = weekdays[date.getDay()]
  return `${month}月${day}日 ${weekday}`
}

export function getRelativeDay(dateStr: string): string {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const target = new Date(dateStr)
  target.setHours(0, 0, 0, 0)
  const diff = (target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
  
  if (diff === 0) return '今天'
  if (diff === 1) return '明天'
  if (diff === -1) return '昨天'
  if (diff === 2) return '后天'
  return ''
}

export function getTodayString(): string {
  const today = new Date()
  return today.toISOString().split('T')[0]
}

export function getTomorrowString(): string {
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  return tomorrow.toISOString().split('T')[0]
}
