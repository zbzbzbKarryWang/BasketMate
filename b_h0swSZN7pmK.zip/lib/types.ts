// 食材类型
export interface Ingredient {
  id: string
  name: string
  quantity: number
  unit: string
  addedAt: Date
}

// 菜谱类型
export interface Recipe {
  id: string
  name: string
  category: string
  ingredients: { name: string; quantity: number; unit: string }[]
}

// 早餐选项
export interface BreakfastOption {
  id: string
  name: string
  emoji: string
}

// 用餐计划
export interface MealPlan {
  id: string
  date: string
  breakfast: BreakfastOption | null
  recipes: Recipe[]
  shoppingListItems: number
}

// 库存项
export interface InventoryItem {
  id: string
  name: string
  quantity: number
  unit: string
  addedAt: Date
}

// 采购项
export interface ShoppingItem {
  id: string
  name: string
  quantity: number
  unit: string
  price: number
  store: string
  checked: boolean
}

// 比价项
export interface PriceItem {
  id: string
  ingredient: string
  store: string
  price: number
}
