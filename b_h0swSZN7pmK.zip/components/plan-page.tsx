"use client"

import { useState } from 'react'
import { Plus, Save, Trash2, Edit2, Calendar, ShoppingCart } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MealPlanner } from '@/components/meal-planner'
import { ConfirmModal } from '@/components/confirm-modal'
import { RecipeDrawer } from '@/components/recipe-drawer'
import { useAppStore } from '@/lib/store'
import { formatDate, getRelativeDay, getTomorrowString } from '@/lib/mock-data'
import type { Recipe } from '@/lib/types'
import { cn } from '@/lib/utils'

export function PlanPage() {
  const { mealPlans, updateMealPlan, deleteMealPlan } = useAppStore()
  
  const [showPlanner, setShowPlanner] = useState(false)
  const [plannerDate, setPlannerDate] = useState<string | undefined>()
  const [editingPlanId, setEditingPlanId] = useState<string | null>(null)
  const [modifiedPlans, setModifiedPlans] = useState<Set<string>>(new Set())
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)
  const [showRecipeDrawer, setShowRecipeDrawer] = useState(false)
  const [editingRecipePlanId, setEditingRecipePlanId] = useState<string | null>(null)

  // 按日期倒序排列
  const sortedPlans = [...mealPlans].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  )

  const handleNewPlan = () => {
    setPlannerDate(getTomorrowString())
    setShowPlanner(true)
  }

  const handleSavePlan = (planId: string) => {
    setModifiedPlans(prev => {
      const next = new Set(prev)
      next.delete(planId)
      return next
    })
  }

  const handleDeletePlan = (planId: string) => {
    deleteMealPlan(planId)
    setDeleteConfirm(null)
  }

  const handleEditRecipes = (planId: string) => {
    setEditingRecipePlanId(planId)
    setShowRecipeDrawer(true)
  }

  const handleRecipesConfirm = (recipes: Recipe[]) => {
    if (editingRecipePlanId) {
      updateMealPlan(editingRecipePlanId, { recipes })
      setModifiedPlans(prev => new Set(prev).add(editingRecipePlanId))
    }
    setEditingRecipePlanId(null)
  }

  if (showPlanner) {
    return (
      <MealPlanner 
        targetDate={plannerDate}
        onBack={() => setShowPlanner(false)}
      />
    )
  }

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* 顶部栏 */}
      <header className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border z-10">
        <div className="flex items-center justify-between px-4 h-14">
          <h1 className="font-semibold">我的计划</h1>
          <Button size="sm" onClick={handleNewPlan} className="gap-1">
            <Plus className="w-4 h-4" />
            新建
          </Button>
        </div>
      </header>

      <main className="flex-1 px-4 py-4 space-y-3">
        {sortedPlans.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <Calendar className="w-12 h-12 mb-3 opacity-50" />
            <p className="text-sm">暂无计划</p>
            <Button variant="link" onClick={handleNewPlan} className="mt-2">
              创建第一个计划
            </Button>
          </div>
        ) : (
          sortedPlans.map(plan => {
            const isModified = modifiedPlans.has(plan.id)
            const relativeDay = getRelativeDay(plan.date)
            
            return (
              <Card key={plan.id} className="shadow-sm">
                <CardContent className="p-4">
                  {/* 卡片头部 */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleSavePlan(plan.id)}
                        className={cn(
                          "text-xs px-2 py-1 rounded transition-colors",
                          isModified 
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground"
                        )}
                      >
                        <Save className="w-3 h-3 inline mr-1" />
                        保存
                      </button>
                    </div>
                    <button
                      onClick={() => setDeleteConfirm(plan.id)}
                      className="text-xs px-2 py-1 rounded bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors"
                    >
                      <Trash2 className="w-3 h-3 inline mr-1" />
                      删除
                    </button>
                  </div>

                  {/* 日期 */}
                  <div className="font-medium mb-3">
                    {formatDate(plan.date)}
                    {relativeDay && (
                      <span className="ml-2 text-sm text-primary">{relativeDay}</span>
                    )}
                  </div>

                  {/* 早餐 */}
                  {plan.breakfast && (
                    <div className="flex items-center justify-between py-2 border-b border-border">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{plan.breakfast.emoji}</span>
                        <span className="text-sm">早餐: {plan.breakfast.name}</span>
                      </div>
                      <button 
                        className="text-xs text-primary hover:underline"
                        onClick={() => {
                          setPlannerDate(plan.date)
                          setShowPlanner(true)
                        }}
                      >
                        修改
                      </button>
                    </div>
                  )}

                  {/* 正餐 */}
                  {plan.recipes.length > 0 && (
                    <div className="py-2 border-b border-border">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-muted-foreground">正餐菜谱</span>
                        <button 
                          className="text-xs text-primary hover:underline"
                          onClick={() => handleEditRecipes(plan.id)}
                        >
                          修改
                        </button>
                      </div>
                      <div className="space-y-1">
                        {plan.recipes.map(recipe => (
                          <div key={recipe.id} className="text-sm">
                            {recipe.name}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* 关联采购清单 */}
                  <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                    <ShoppingCart className="w-3.5 h-3.5" />
                    已关联采购清单项: {plan.shoppingListItems}项
                  </div>
                </CardContent>
              </Card>
            )
          })
        )}
      </main>

      {/* 删除确认弹窗 */}
      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="删除计划"
        message="确定要删除这个计划吗？此操作无法撤销。"
        confirmText="删除"
        cancelText="取消"
        variant="destructive"
        onConfirm={() => deleteConfirm && handleDeletePlan(deleteConfirm)}
        onCancel={() => setDeleteConfirm(null)}
      />

      {/* 菜谱选择抽屉 */}
      <RecipeDrawer
        isOpen={showRecipeDrawer}
        onClose={() => {
          setShowRecipeDrawer(false)
          setEditingRecipePlanId(null)
        }}
        onConfirm={handleRecipesConfirm}
        initialSelected={
          editingRecipePlanId 
            ? mealPlans.find(p => p.id === editingRecipePlanId)?.recipes || []
            : []
        }
      />
    </div>
  )
}
