"use client"

import { useState, useRef } from 'react'
import { Plus, Minus } from 'lucide-react'
import { breakfastOptions } from '@/lib/mock-data'
import type { BreakfastOption } from '@/lib/types'
import { cn } from '@/lib/utils'

interface BreakfastWheelProps {
  onSelect: (option: BreakfastOption) => void
  onAddTemp: () => void
  onRemove: (option: BreakfastOption) => void
}

export function BreakfastWheel({ onSelect, onAddTemp, onRemove }: BreakfastWheelProps) {
  const [isSpinning, setIsSpinning] = useState(false)
  const [rotation, setRotation] = useState(0)
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null)
  const wheelRef = useRef<HTMLDivElement>(null)
  
  const options = breakfastOptions
  const segmentAngle = 360 / options.length

  const spin = () => {
    if (isSpinning) return
    
    setIsSpinning(true)
    setSelectedIndex(null)
    
    // 随机选择一个选项
    const randomIndex = Math.floor(Math.random() * options.length)
    // 计算旋转角度: 多转几圈 + 对准选中项
    const spins = 5 + Math.random() * 3 // 5-8圈
    const targetAngle = spins * 360 + (360 - randomIndex * segmentAngle - segmentAngle / 2)
    
    setRotation(prev => prev + targetAngle)
    
    setTimeout(() => {
      setIsSpinning(false)
      setSelectedIndex(randomIndex)
      onSelect(options[randomIndex])
    }, 4000)
  }

  const getSegmentPath = (index: number, total: number, radius: number) => {
    const angle = 360 / total
    const startAngle = index * angle - 90
    const endAngle = startAngle + angle
    
    const startRad = (startAngle * Math.PI) / 180
    const endRad = (endAngle * Math.PI) / 180
    
    const x1 = radius + radius * Math.cos(startRad)
    const y1 = radius + radius * Math.sin(startRad)
    const x2 = radius + radius * Math.cos(endRad)
    const y2 = radius + radius * Math.sin(endRad)
    
    const largeArc = angle > 180 ? 1 : 0
    
    return `M ${radius} ${radius} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`
  }

  const colors = [
    '#22c55e', '#f97316', '#3b82f6', '#eab308', 
    '#ec4899', '#8b5cf6', '#14b8a6', '#f43f5e'
  ]

  return (
    <div className="flex flex-col items-center">
      {/* 指针 */}
      <div className="relative z-10 -mb-3">
        <div className="w-0 h-0 border-l-[12px] border-r-[12px] border-t-[20px] border-l-transparent border-r-transparent border-t-primary" />
      </div>
      
      {/* 转盘 */}
      <div className="relative">
        <div 
          ref={wheelRef}
          className={cn(
            "relative w-64 h-64 rounded-full shadow-lg",
            "transition-transform duration-[4000ms] ease-out"
          )}
          style={{ transform: `rotate(${rotation}deg)` }}
        >
          <svg viewBox="0 0 200 200" className="w-full h-full">
            {options.map((option, index) => (
              <g key={option.id}>
                <path
                  d={getSegmentPath(index, options.length, 100)}
                  fill={colors[index % colors.length]}
                  stroke="white"
                  strokeWidth="1"
                />
                <text
                  x="100"
                  y="35"
                  textAnchor="middle"
                  fill="white"
                  fontSize="10"
                  fontWeight="500"
                  transform={`rotate(${index * segmentAngle + segmentAngle / 2}, 100, 100)`}
                >
                  {option.emoji} {option.name}
                </text>
              </g>
            ))}
          </svg>
          
          {/* 中心按钮 */}
          <button
            onClick={spin}
            disabled={isSpinning}
            className={cn(
              "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2",
              "w-16 h-16 rounded-full bg-white shadow-md",
              "flex items-center justify-center",
              "text-primary font-bold text-lg",
              "hover:bg-gray-50 active:scale-95 transition-all",
              "disabled:opacity-50 disabled:cursor-not-allowed"
            )}
          >
            {isSpinning ? '...' : '转'}
          </button>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex items-center justify-center gap-6 mt-4">
        <button 
          onClick={onAddTemp}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <Plus className="w-4 h-4" />
          临时添加
        </button>
        <button 
          onClick={() => selectedIndex !== null && onRemove(options[selectedIndex])}
          disabled={selectedIndex === null}
          className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-destructive transition-colors disabled:opacity-50"
        >
          <Minus className="w-4 h-4" />
          删除此项
        </button>
      </div>
    </div>
  )
}
