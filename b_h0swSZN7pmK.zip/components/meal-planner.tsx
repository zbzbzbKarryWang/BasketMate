"use client"

import { useState } from 'react'
import { ArrowLeft, Check } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { BreakfastWheel } from '@/components/breakfast-wheel'
import { ConfirmModal } from '@/components/confirm-modal'
import { RecipeDrawer } from '@/components/recipe-drawer'
import { useAppStore } from '@/lib/store'
import { recipes as allRecipes, formatDate, getRelativeDay, getTomorrowString } from '@/lib/mock-data'
import type { BreakfastOption, Recipe } from '@/lib/types'
import { cn } from '@/lib/utils'

interface MealPlannerProps {
  targetDate?: string
  onBack: () => void
}

export function MealPlanner({ targetDate, onBack }: MealPlannerProps) {
  const date = targetDate || getTomorrowString()
  const relativeDay = getRelativeDay(date)
  
  const { inventory, addMealPlan } = useAppStore()
  
  const [selectedBreakfast, setSelectedBreakfast] = useState<BreakfastOption | null>(null)
  const [showBreakfastConfirm, setShowBreakfastConfirm] = useState(false)
  const [pendingBreakfast, setPendingBreakfast] = useState<BreakfastOption | null>(null)
  
  const [selectedRecipes, setSelectedRecipes] = useState<Recipe[]>([])
  const [showRecipeDrawer, setShowRecipeDrawer] = useState(false)
  
  // 根据库存推荐菜谱（按添加时间排序，优先使用最早添加的食材）
  const recommendedRecipes = allRecipes
    .map(recipe => {
      const matchingIngredients = recipe.ingredients.filter(ing =>
        inventory.some(inv => inv.name === ing.name && inv.quantity >= ing.quantity)
      )
      const oldestMatch = inventory
        .filter(inv => recipe.ingredients.some(ing => ing.name === inv.name))
        .sort((a, b) => new Date(a.addedAt).getTime() - new Date(b.addedAt).getTime())[0]
      
      return {
        recipe,
        matchCount: matchingIngredients.length,
        oldestDate: oldestMatch?.addedAt || new Date()
      }
    })
    .filter(r => r.matchCount > 0)
    .sort((a, b) => new Date(a.oldestDate).getTime() - new Date(b.oldestDate).getTime())
    .slice(0, 5)

  const handleBreakfastSelect = (option: BreakfastOption) => {
    setPendingBreakfast(option)
    setShowBreakfastConfirm(true)
  }

  const confirmBreakfast = () => {
    if (pendingBreakfast) {
      setSelectedBreakfast(pendingBreakfast)
    }
    setShowBreakfastConfirm(false)
    setPendingBreakfast(null)
  }

  const toggleRecommendedRecipe = (recipe: Recipe) => {
    setSelectedRecipes(prev => 
      prev.some(r => r.id === recipe.id)
        ? prev.filter(r => r.id !== recipe.id)
        : [...prev, recipe]
    )
  }

  const handleConfirmMeal = () => {
    if (selectedBreakfast || selectedRecipes.length > 0) {
      addMealPlan({
        id: Date.now().toString(),
        date,
        breakfast: selectedBreakfast,
        recipes: selectedRecipes,
        shoppingListItems: selectedRecipes.reduce((acc, r) => acc + r.ingredients.length, 0)
      })
      onBack()
    }
  }

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* 顶部导航 */}
      <header className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border z-10">
        <div className="flex items-center px-4 h-14">
          <button onClick={onBack} className="mr-3 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-semibold text-sm">
            为 {formatDate(date)}{relativeDay && `（${relativeDay}）`} 制定计划
          </h1>
        </div>
      </header>

      <main className="flex-1 px-4 py-4 space-y-4">
        {/* 早餐转盘 */}
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">早餐选择</CardTitle>
            {selectedBreakfast && (
              <div className="text-sm text-primary flex items-center gap-1">
                <Check className="w-4 h-4" />
                已选择: {selectedBreakfast.emoji} {selectedBreakfast.name}
              </div>
            )}
          </CardHeader>
          <CardContent className="pt-2">
            <BreakfastWheel
              onSelect={handleBreakfastSelect}
              onAddTemp={() => {}}
              onRemove={() => {}}
            />
          </CardContent>
        </Card>

        {/* 正餐推荐 */}
        <Card className="shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">正餐推荐</CardTitle>
            <p className="text-xs text-muted-foreground">根据库存推荐（最早添加食材优先）</p>
          </CardHeader>
          <CardContent>
            {recommendedRecipes.length > 0 ? (
              <div className="space-y-2">
                {recommendedRecipes.map(({ recipe }) => (
                  <button
                    key={recipe.id}
                    onClick={() => toggleRecommendedRecipe(recipe)}
                    className={cn(
                      "w-full p-3 rounded-lg border text-left transition-all",
                      selectedRecipes.some(r => r.id === recipe.id)
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm">{recipe.name}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {recipe.ingredients.map(i => `${i.name}${i.quantity}${i.unit}`).join(' · ')}
                        </div>
                      </div>
                      <div className={cn(
                        "w-5 h-5 rounded border-2 flex items-center justify-center transition-colors",
                        selectedRecipes.some(r => r.id === recipe.id)
                          ? "border-primary bg-primary"
                          : "border-muted-foreground"
                      )}>
                        {selectedRecipes.some(r => r.id === recipe.id) && (
                          <Check className="w-3 h-3 text-primary-foreground" />
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                库存不足，无法推荐菜谱
              </p>
            )}
            
            <div className="flex gap-3 mt-4">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setShowRecipeDrawer(true)}
              >
                手动加菜
              </Button>
              <Button 
                className="flex-1"
                onClick={handleConfirmMeal}
                disabled={!selectedBreakfast && selectedRecipes.length === 0}
              >
                确认计划
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* 早餐确认弹窗 */}
      <ConfirmModal
        isOpen={showBreakfastConfirm}
        title="确认早餐"
        message={`早餐为：${pendingBreakfast?.emoji || ''} ${pendingBreakfast?.name || ''}`}
        onConfirm={confirmBreakfast}
        onCancel={() => {
          setShowBreakfastConfirm(false)
          setPendingBreakfast(null)
        }}
      />

      {/* 菜谱选择抽屉 */}
      <RecipeDrawer
        isOpen={showRecipeDrawer}
        onClose={() => setShowRecipeDrawer(false)}
        onConfirm={setSelectedRecipes}
        initialSelected={selectedRecipes}
      />
    </div>
  )
}
