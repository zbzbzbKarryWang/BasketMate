"use client"

import { useEffect } from 'react'
import { X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface ConfirmModalProps {
  isOpen: boolean
  title: string
  message: string
  confirmText?: string
  cancelText?: string
  onConfirm: () => void
  onCancel: () => void
  variant?: 'default' | 'destructive'
}

export function ConfirmModal({
  isOpen,
  title,
  message,
  confirmText = '确认',
  cancelText = '取消',
  onConfirm,
  onCancel,
  variant = 'default'
}: ConfirmModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* 遮罩 */}
      <div 
        className="absolute inset-0 bg-black/50"
        onClick={onCancel}
      />
      
      {/* 弹窗内容 */}
      <div className="relative bg-card rounded-xl shadow-xl w-[280px] overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">{title}</h3>
            <button 
              onClick={onCancel}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-sm text-muted-foreground">{message}</p>
        </div>
        
        <div className="flex border-t border-border">
          <button
            onClick={onCancel}
            className="flex-1 py-3 text-sm text-muted-foreground hover:bg-muted transition-colors"
          >
            {cancelText}
          </button>
          <div className="w-px bg-border" />
          <button
            onClick={onConfirm}
            className={cn(
              "flex-1 py-3 text-sm font-medium transition-colors",
              variant === 'destructive' 
                ? "text-destructive hover:bg-destructive/10"
                : "text-primary hover:bg-primary/10"
            )}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  )
}
