"use client"

import { useState, useMemo, useRef } from 'react'
import { Plus, TrendingDown, Upload, X, Store } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useAppStore } from '@/lib/store'

export function PricePage() {
  const { priceList, addPriceItem } = useAppStore()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [stores, setStores] = useState<string[]>(() => {
    // 从现有数据中提取店铺列表
    const existingStores = [...new Set(priceList.map(item => item.store))]
    return existingStores.length > 0 ? existingStores : ['盒马', '叮咚', '美团']
  })
  const [selectedStore, setSelectedStore] = useState('')
  const [newStoreName, setNewStoreName] = useState('')
  const [isAddingStore, setIsAddingStore] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // 获取所有店铺
  const allStores = useMemo(() => {
    const storesFromData = [...new Set(priceList.map(item => item.store))]
    return [...new Set([...stores, ...storesFromData])]
  }, [priceList, stores])

  // 获取所有食材
  const allIngredients = useMemo(() => {
    return [...new Set(priceList.map(item => item.ingredient))]
  }, [priceList])

  // 构建价格矩阵：食材 -> 店铺 -> 价格
  const priceMatrix = useMemo(() => {
    const matrix: Record<string, Record<string, number | null>> = {}
    
    allIngredients.forEach(ingredient => {
      matrix[ingredient] = {}
      allStores.forEach(store => {
        const item = priceList.find(p => p.ingredient === ingredient && p.store === store)
        matrix[ingredient][store] = item ? item.price : null
      })
    })
    
    return matrix
  }, [priceList, allIngredients, allStores])

  // 找出每行的最低价
  const getLowestPrice = (ingredient: string) => {
    const prices = Object.values(priceMatrix[ingredient] || {}).filter(p => p !== null) as number[]
    return prices.length > 0 ? Math.min(...prices) : null
  }

  const handleAddStore = () => {
    if (newStoreName.trim() && !stores.includes(newStoreName.trim())) {
      setStores(prev => [...prev, newStoreName.trim()])
      setSelectedStore(newStoreName.trim())
      setNewStoreName('')
      setIsAddingStore(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // 只接受表格文件
      const validTypes = [
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/csv'
      ]
      if (validTypes.includes(file.type) || file.name.endsWith('.csv') || file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        setUploadedFile(file)
      } else {
        alert('请上传表格文件（.csv, .xlsx, .xls）')
      }
    }
  }

  const handleUpload = () => {
    if (!selectedStore || !uploadedFile) return
    
    // 模拟上传处理 - 实际项目中会解析文件内容
    // 这里简单添加一些示例数据
    const mockIngredients = ['西红柿', '黄瓜', '土豆', '胡萝卜', '青椒']
    mockIngredients.forEach((ingredient, index) => {
      const existingItem = priceList.find(p => p.ingredient === ingredient && p.store === selectedStore)
      if (!existingItem) {
        addPriceItem({
          id: `${Date.now()}-${index}`,
          ingredient,
          store: selectedStore,
          price: Math.round((Math.random() * 10 + 2) * 100) / 100
        })
      }
    })
    
    setIsModalOpen(false)
    setSelectedStore('')
    setUploadedFile(null)
  }

  const handleCancel = () => {
    setIsModalOpen(false)
    setSelectedStore('')
    setUploadedFile(null)
    setIsAddingStore(false)
    setNewStoreName('')
  }

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* 顶部栏 */}
      <header className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border z-10">
        <div className="flex items-center justify-between px-4 h-14">
          <h1 className="font-semibold">价格对比</h1>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => setIsModalOpen(true)}
            className="gap-1"
          >
            <Plus className="w-4 h-4" />
            添加
          </Button>
        </div>
      </header>

      <main className="flex-1 px-4 py-4">
        {allIngredients.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <TrendingDown className="w-12 h-12 mb-3 opacity-50" />
            <p className="text-sm">暂无价格数据</p>
            <Button 
              variant="link" 
              onClick={() => setIsModalOpen(true)}
              className="mt-2"
            >
              添加第一条记录
            </Button>
          </div>
        ) : (
          <Card className="shadow-sm overflow-hidden">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50 border-b border-border">
                      <th className="text-left px-3 py-3 font-medium text-muted-foreground whitespace-nowrap">
                        食材名
                      </th>
                      {allStores.map(store => (
                        <th key={store} className="text-right px-3 py-3 font-medium text-muted-foreground whitespace-nowrap">
                          {store}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {allIngredients.map(ingredient => {
                      const lowestPrice = getLowestPrice(ingredient)
                      
                      return (
                        <tr key={ingredient} className="hover:bg-muted/30 transition-colors">
                          <td className="px-3 py-3 font-medium whitespace-nowrap">
                            {ingredient}
                          </td>
                          {allStores.map(store => {
                            const price = priceMatrix[ingredient]?.[store]
                            const isLowest = price !== null && price === lowestPrice && 
                              Object.values(priceMatrix[ingredient] || {}).filter(p => p !== null).length > 1
                            
                            return (
                              <td 
                                key={store} 
                                className={`px-3 py-3 text-right whitespace-nowrap ${
                                  isLowest ? 'text-primary font-semibold' : ''
                                }`}
                              >
                                {price !== null ? `¥${price.toFixed(2)}` : '-'}
                              </td>
                            )
                          })}
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}
      </main>

      {/* 添加弹窗 */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center">
          <div className="bg-card w-full max-w-md rounded-t-2xl animate-in slide-in-from-bottom duration-300">
            <div className="p-4 border-b border-border">
              <h2 className="font-semibold text-center">添加价格数据</h2>
            </div>
            
            <div className="p-4 space-y-4">
              {/* 选择店铺 */}
              <div className="space-y-2">
                <label className="text-sm font-medium">选择店铺</label>
                {!isAddingStore ? (
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-2">
                      {stores.map(store => (
                        <button
                          key={store}
                          onClick={() => setSelectedStore(store)}
                          className={`px-3 py-1.5 rounded-lg text-sm border transition-colors ${
                            selectedStore === store
                              ? 'bg-primary text-primary-foreground border-primary'
                              : 'bg-background border-border hover:border-primary'
                          }`}
                        >
                          {store}
                        </button>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsAddingStore(true)}
                      className="gap-1"
                    >
                      <Store className="w-4 h-4" />
                      添加店铺
                    </Button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Input
                      placeholder="输入店铺名称"
                      value={newStoreName}
                      onChange={(e) => setNewStoreName(e.target.value)}
                      className="flex-1"
                      autoFocus
                    />
                    <Button onClick={handleAddStore} size="sm">
                      确定
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setIsAddingStore(false)
                        setNewStoreName('')
                      }}
                    >
                      取消
                    </Button>
                  </div>
                )}
              </div>

              {/* 上传表格 */}
              <div className="space-y-2">
                <label className="text-sm font-medium">上传价格表格</label>
                <div 
                  className="border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-primary transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {uploadedFile ? (
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-sm text-foreground">{uploadedFile.name}</span>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation()
                          setUploadedFile(null)
                        }}
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">点击上传表格文件</p>
                      <p className="text-xs text-muted-foreground mt-1">支持 .csv, .xlsx, .xls 格式</p>
                    </>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.xlsx,.xls,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>
            </div>

            {/* 底部按钮 */}
            <div className="flex gap-3 p-4 border-t border-border">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={handleCancel}
              >
                取消
              </Button>
              <Button 
                className="flex-1"
                onClick={handleUpload}
                disabled={!selectedStore || !uploadedFile}
              >
                上传
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
