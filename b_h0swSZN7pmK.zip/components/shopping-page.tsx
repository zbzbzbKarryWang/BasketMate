"use client"

import { useState } from 'react'
import { Plus, Minus, Check, ShoppingCart } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { RecipeDrawer } from '@/components/recipe-drawer'
import { useAppStore } from '@/lib/store'
import type { Recipe } from '@/lib/types'
import { cn } from '@/lib/utils'

export function ShoppingPage() {
  const { shoppingList, toggleShoppingItem, updateShoppingQuantity, addShoppingItem } = useAppStore()
  const [showRecipeDrawer, setShowRecipeDrawer] = useState(false)

  // 按店铺分组
  const groupedByStore = shoppingList.reduce((acc, item) => {
    if (!acc[item.store]) {
      acc[item.store] = []
    }
    acc[item.store].push(item)
    return acc
  }, {} as Record<string, typeof shoppingList>)

  const handleQuantityChange = (id: string, delta: number) => {
    const item = shoppingList.find(i => i.id === id)
    if (item) {
      const newQuantity = Math.max(0, item.quantity + delta)
      updateShoppingQuantity(id, newQuantity)
    }
  }

  const handleAddFromRecipe = (recipes: Recipe[]) => {
    recipes.forEach(recipe => {
      recipe.ingredients.forEach(ing => {
        addShoppingItem({
          id: Date.now().toString() + Math.random(),
          name: ing.name,
          quantity: ing.quantity,
          unit: ing.unit,
          price: 0,
          store: '待定',
          checked: false
        })
      })
    })
  }

  const handleComplete = () => {
    // 采购完成逻辑
    alert('采购完成！已勾选的食材将添加到库存。')
  }

  const allChecked = shoppingList.length > 0 && shoppingList.every(i => i.checked)
  const checkedCount = shoppingList.filter(i => i.checked).length

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* 顶部栏 */}
      <header className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border z-10">
        <div className="flex items-center justify-between px-4 h-14">
          <h1 className="font-semibold">采购清单</h1>
          <Button 
            size="sm" 
            variant="outline"
            onClick={() => setShowRecipeDrawer(true)}
            className="gap-1"
          >
            <Plus className="w-4 h-4" />
            加菜
          </Button>
        </div>
      </header>

      <main className="flex-1 px-4 py-4 space-y-4">
        {shoppingList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <ShoppingCart className="w-12 h-12 mb-3 opacity-50" />
            <p className="text-sm">采购清单为空</p>
            <Button 
              variant="link" 
              onClick={() => setShowRecipeDrawer(true)}
              className="mt-2"
            >
              从菜谱添加食材
            </Button>
          </div>
        ) : (
          Object.entries(groupedByStore).map(([store, items]) => (
            <Card key={store} className="shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">{store}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {items.map(item => (
                    <div 
                      key={item.id}
                      className={cn(
                        "flex items-center gap-3 p-2 rounded-lg transition-colors",
                        item.checked ? "bg-muted/50" : "bg-muted"
                      )}
                    >
                      {/* 勾选框 */}
                      <button
                        onClick={() => toggleShoppingItem(item.id)}
                        className={cn(
                          "w-5 h-5 rounded border-2 flex items-center justify-center transition-colors flex-shrink-0",
                          item.checked
                            ? "border-primary bg-primary"
                            : "border-muted-foreground"
                        )}
                      >
                        {item.checked && (
                          <Check className="w-3 h-3 text-primary-foreground" />
                        )}
                      </button>

                      {/* 食材名称 */}
                      <div className={cn(
                        "flex-1 text-sm",
                        item.checked && "line-through text-muted-foreground"
                      )}>
                        {item.name}
                      </div>

                      {/* 单价 */}
                      <div className="text-xs text-muted-foreground w-14 text-right">
                        {item.price > 0 ? `¥${item.price}` : '-'}
                      </div>

                      {/* 数量控制 */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleQuantityChange(item.id, -1)}
                          className="w-6 h-6 rounded bg-background flex items-center justify-center hover:bg-muted-foreground/20 transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-10 text-center text-sm">
                          {item.quantity}{item.unit}
                        </span>
                        <button
                          onClick={() => handleQuantityChange(item.id, 1)}
                          className="w-6 h-6 rounded bg-background flex items-center justify-center hover:bg-muted-foreground/20 transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </main>

      {/* 底部按钮 */}
      {shoppingList.length > 0 && (
        <div className="fixed bottom-20 left-0 right-0 px-4 pb-4 bg-gradient-to-t from-background to-transparent pt-8">
          <div className="max-w-md mx-auto">
            <Button 
              className="w-full gap-2" 
              size="lg"
              onClick={handleComplete}
              disabled={checkedCount === 0}
            >
              <Check className="w-4 h-4" />
              采购完成 ({checkedCount}/{shoppingList.length})
            </Button>
          </div>
        </div>
      )}

      {/* 菜谱选择抽屉 */}
      <RecipeDrawer
        isOpen={showRecipeDrawer}
        onClose={() => setShowRecipeDrawer(false)}
        onConfirm={handleAddFromRecipe}
        initialSelected={[]}
      />
    </div>
  )
}
