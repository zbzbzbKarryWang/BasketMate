"use client"

import { useState } from 'react'
import { Plus, BookOpen, Search } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useAppStore } from '@/lib/store'
import { cn } from '@/lib/utils'

export function RecipesPage() {
  const { recipes, addRecipe } = useAppStore()
  const [search, setSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  // 获取所有分类
  const categories = [...new Set(recipes.map(r => r.category))]

  // 过滤菜谱
  const filteredRecipes = recipes.filter(r => {
    const matchesSearch = r.name.includes(search) || r.ingredients.some(i => i.name.includes(search))
    const matchesCategory = !selectedCategory || r.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* 顶部栏 */}
      <header className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border z-10">
        <div className="flex items-center justify-between px-4 h-14">
          <h1 className="font-semibold">菜谱库</h1>
          <Button size="sm" className="gap-1">
            <Plus className="w-4 h-4" />
            添加
          </Button>
        </div>
        
        {/* 搜索栏 */}
        <div className="px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="搜索菜谱或食材..."
              className="pl-9"
            />
          </div>
        </div>

        {/* 分类标签 */}
        <div className="px-4 pb-3 flex gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedCategory(null)}
            className={cn(
              "px-3 py-1 rounded-full text-xs whitespace-nowrap transition-colors",
              !selectedCategory 
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted-foreground/20"
            )}
          >
            全部
          </button>
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={cn(
                "px-3 py-1 rounded-full text-xs whitespace-nowrap transition-colors",
                selectedCategory === cat
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted-foreground/20"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </header>

      <main className="flex-1 px-4 py-4">
        {filteredRecipes.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <BookOpen className="w-12 h-12 mb-3 opacity-50" />
            <p className="text-sm">没有找到菜谱</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {filteredRecipes.map(recipe => (
              <Card key={recipe.id} className="shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium">{recipe.name}</h3>
                      <span className="inline-block mt-1 px-2 py-0.5 text-xs bg-muted rounded-full text-muted-foreground">
                        {recipe.category}
                      </span>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {recipe.ingredients.map((ing, idx) => (
                      <span 
                        key={idx}
                        className="px-2 py-0.5 text-xs bg-primary/10 text-primary rounded"
                      >
                        {ing.name}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
