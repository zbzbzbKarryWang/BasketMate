"use client"

import { useState, useMemo } from 'react'
import { Plus, Minus, ArrowUpDown, Save, Package, ChefHat } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useAppStore } from '@/lib/store'
import { recipes } from '@/lib/mock-data'

type SortType = 'date-desc' | 'quantity-desc'

export function InventoryPage() {
  const { inventory, updateInventoryItem } = useAppStore()
  const [sortType, setSortType] = useState<SortType>('date-desc')
  const [hasChanges, setHasChanges] = useState(false)

  const sortedInventory = [...inventory].sort((a, b) => {
    if (sortType === 'date-desc') {
      return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime()
    } else {
      return b.quantity - a.quantity
    }
  })

  // 根据库存推荐菜谱
  const recommendedRecipes = useMemo(() => {
    const inventoryNames = inventory.map(item => item.name.toLowerCase())
    
    // 计算每个菜谱的匹配度（有多少食材在库存中）
    const recipesWithScore = recipes.map(recipe => {
      const matchedIngredients = recipe.ingredients.filter(ing => 
        inventoryNames.some(invName => 
          invName.includes(ing.name.toLowerCase()) || ing.name.toLowerCase().includes(invName)
        )
      )
      return {
        ...recipe,
        matchCount: matchedIngredients.length,
        totalIngredients: recipe.ingredients.length,
        matchedNames: matchedIngredients.map(i => i.name)
      }
    })
    
    // 返回匹配度大于0的菜谱，按匹配度排序
    return recipesWithScore
      .filter(r => r.matchCount > 0)
      .sort((a, b) => b.matchCount - a.matchCount)
      .slice(0, 4)
  }, [inventory])

  const handleQuantityChange = (id: string, delta: number) => {
    const item = inventory.find(i => i.id === id)
    if (item) {
      const newQuantity = Math.max(0, item.quantity + delta)
      updateInventoryItem(id, newQuantity)
      setHasChanges(true)
    }
  }

  const toggleSort = () => {
    setSortType(prev => prev === 'date-desc' ? 'quantity-desc' : 'date-desc')
  }

  const handleSave = () => {
    setHasChanges(false)
    // 保存逻辑
  }

  const formatDate = (date: Date) => {
    const d = new Date(date)
    return `${d.getMonth() + 1}/${d.getDate()}`
  }

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* 顶部栏 */}
      <header className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border z-10">
        <div className="flex items-center justify-between px-4 h-14">
          <h1 className="font-semibold">我的库存</h1>
          <button 
            onClick={toggleSort}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowUpDown className="w-4 h-4" />
            {sortType === 'date-desc' ? '按时间' : '按数量'}
          </button>
        </div>
      </header>

      <main className="flex-1 px-4 py-4">
        {inventory.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground">
            <Package className="w-12 h-12 mb-3 opacity-50" />
            <p className="text-sm">库存为空</p>
          </div>
        ) : (
          <Card className="shadow-sm">
            <CardContent className="p-0">
              {/* 表头 */}
              <div className="flex items-center px-4 py-3 border-b border-border bg-muted/50 text-xs font-medium text-muted-foreground">
                <div className="flex-1">食材</div>
                <div className="w-28 text-center">数量</div>
                <div className="w-12 text-center">单位</div>
                <div className="w-14 text-right">添加日期</div>
              </div>
              
              {/* 数据行 */}
              <div className="divide-y divide-border">
                {sortedInventory.map(item => (
                  <div 
                    key={item.id}
                    className="flex items-center px-4 py-3"
                  >
                    <div className="flex-1 text-sm font-medium">{item.name}</div>
                    
                    {/* 数量控制 */}
                    <div className="w-28 flex items-center justify-center gap-1">
                      <button
                        onClick={() => handleQuantityChange(item.id, -1)}
                        className="w-6 h-6 rounded bg-muted flex items-center justify-center hover:bg-muted-foreground/20 transition-colors"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-10 text-center text-sm">{item.quantity}</span>
                      <button
                        onClick={() => handleQuantityChange(item.id, 1)}
                        className="w-6 h-6 rounded bg-muted flex items-center justify-center hover:bg-muted-foreground/20 transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                    
                    <div className="w-12 text-center text-sm text-muted-foreground">
                      {item.unit}
                    </div>
                    <div className="w-14 text-right text-xs text-muted-foreground">
                      {formatDate(item.addedAt)}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* 根据库存推荐菜谱 */}
        {recommendedRecipes.length > 0 && (
          <div className="mt-6">
            <div className="flex items-center gap-2 mb-3">
              <ChefHat className="w-5 h-5 text-primary" />
              <h2 className="font-semibold text-foreground">根据库存推荐</h2>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {recommendedRecipes.map(recipe => (
                <Card key={recipe.id} className="shadow-sm">
                  <CardContent className="p-3">
                    <div className="font-medium text-sm mb-1">{recipe.name}</div>
                    <div className="text-xs text-muted-foreground mb-2">
                      {recipe.category}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {recipe.ingredients.map((ing, idx) => (
                        <span 
                          key={idx}
                          className={`text-xs px-1.5 py-0.5 rounded ${
                            recipe.matchedNames.includes(ing.name)
                              ? 'bg-primary/10 text-primary'
                              : 'bg-muted text-muted-foreground'
                          }`}
                        >
                          {ing.name}
                        </span>
                      ))}
                    </div>
                    <div className="mt-2 text-xs text-primary">
                      已有 {recipe.matchCount}/{recipe.totalIngredients} 种食材
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* 保存按钮 */}
      {hasChanges && (
        <div className="fixed bottom-20 left-0 right-0 px-4 pb-4 bg-gradient-to-t from-background to-transparent pt-8">
          <div className="max-w-md mx-auto">
            <Button 
              className="w-full gap-2" 
              size="lg"
              onClick={handleSave}
            >
              <Save className="w-4 h-4" />
              保存更改
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
