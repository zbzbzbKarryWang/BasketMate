"use client"

import { CalendarDays, ShoppingCart, Utensils, Package } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useAppStore } from '@/lib/store'
import { formatDate, getTodayString } from '@/lib/mock-data'

export function HomePage() {
  const { mealPlans, setActiveTab } = useAppStore()
  const today = getTodayString()
  const todayPlan = mealPlans.find(p => p.date === today)

  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* 顶部栏 */}
      <header className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border z-10">
        <div className="flex items-center justify-center px-4 h-12">
          <div className="text-base font-semibold text-foreground">
            {formatDate(today)}
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <main className="flex-1 px-4 py-4">
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-primary" />
              今日计划
            </CardTitle>
          </CardHeader>
          <CardContent>
            {todayPlan ? (
              <div className="space-y-4">
                {/* 早餐 */}
                {todayPlan.breakfast && (
                  <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                    <span className="text-2xl">{todayPlan.breakfast.emoji}</span>
                    <div>
                      <div className="text-xs text-muted-foreground">早餐</div>
                      <div className="font-medium">{todayPlan.breakfast.name}</div>
                    </div>
                  </div>
                )}
                
                {/* 正餐菜谱 */}
                {todayPlan.recipes.length > 0 && (
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <Utensils className="w-3.5 h-3.5" />
                      正餐菜谱
                    </div>
                    <div className="space-y-2">
                      {todayPlan.recipes.map((recipe) => (
                        <div 
                          key={recipe.id}
                          className="p-3 bg-muted rounded-lg"
                        >
                          <div className="font-medium text-sm">{recipe.name}</div>
                          <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-1">
                            {recipe.ingredients.map((ing, idx) => (
                              <span key={idx} className="bg-background px-1.5 py-0.5 rounded">
                                {ing.name}{ing.quantity}{ing.unit}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <Package className="w-12 h-12 mb-3 opacity-50" />
                <p className="text-sm">今日无计划</p>
                <button 
                  onClick={() => setActiveTab('plan')}
                  className="mt-3 text-sm text-primary hover:underline"
                >
                  制定计划
                </button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 快捷操作卡片 */}
        <div className="grid grid-cols-2 gap-3 mt-4">
          <Card 
            className="shadow-sm cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setActiveTab('inventory')}
          >
            <CardContent className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Package className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-sm font-medium">查看库存</div>
                <div className="text-xs text-muted-foreground">管理食材</div>
              </div>
            </CardContent>
          </Card>
          <Card 
            className="shadow-sm cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setActiveTab('shopping')}
          >
            <CardContent className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-full bg-secondary/10 flex items-center justify-center">
                <ShoppingCart className="w-5 h-5 text-secondary" />
              </div>
              <div>
                <div className="text-sm font-medium">采购清单</div>
                <div className="text-xs text-muted-foreground">去买菜</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 吃什么卡片 */}
        <Card 
          className="shadow-sm cursor-pointer hover:shadow-md transition-shadow mt-4"
          onClick={() => setActiveTab('plan')}
        >
          <CardContent className="flex items-center justify-center gap-2 p-2.5">
            <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
              <Utensils className="w-4 h-4 text-primary" />
            </div>
            <span className="text-sm font-medium">吃什么</span>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
